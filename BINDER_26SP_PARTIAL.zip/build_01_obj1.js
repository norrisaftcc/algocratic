// build_01_obj1.js — Objective 1: Cross-Departmental Capstone Collaboration
const fs = require('fs');
const H = require('./helpers');

// -------------------- COVER PAGE --------------------
const cover = H.buildCoverPage({
  eyebrow: "FILE 02 OF 05 · PERFORMANCE REVIEW BINDER",
  title: "Objective 1",
  subtitle: "Cross-Departmental Capstone Collaboration Framework",
  metadata: [
    { label: "Instructor", value: "[REDACTED]" },
    { label: "Courses", value: "CSC 289 (Capstone) · GRD partnering courses" },
    { label: "Review Period", value: "July 1, 2025 – June 30, 2026" },
    { label: "Status", value: "Achieved (January 2026)" },
  ],
  dateLine: "Documentation: Objective Statement + Implementation + Supporting Evidence",
});

// -------------------- OBJECTIVE DOCUMENTATION --------------------
const objectiveBody = [
  ...H.buildDivider({
    eyebrow: "PART A",
    title: "Objective Documentation",
    subtitle: "Statement, methodology, deliverables, outcomes",
    leadingBreak: false,
  }),

  H.h1("Objective Statement"),
  H.pp("**Purpose.** Develop and formalize a cross-departmental collaboration framework between Computer Science and Graphic Design capstone courses by implementing structured processes and assessment methods."),
  H.pp("**Requirements.**"),
  H.bullet("Document and standardize the Creative Brief process with the Graphic Design department"),
  H.bullet("Establish three formal touchpoints / milestones in the collaboration cycle"),
  H.bullet("Create rubrics for evaluating cross-team communication and deliverable integration"),
  H.pp("**Status:** Achieved \u2014 January 2026."),

  H.h1("Why This Work Was the Right Call"),
  H.pp("Before detailing what was built and how, it is worth grounding the decision in what the field already knew."),
  H.pp("The question facing any program that trains future software and design professionals is not whether students will work on cross-functional teams \u2014 they will. The question is whether they will encounter that dynamic for the first time on the job, or arrive having already navigated it, failed at it, recovered from it, and built the communication habits it requires. That distinction is what this initiative addresses, and it is the reason the framework developed here represents more than a curriculum add-on."),

  H.h2("The National Employer Picture"),
  H.pp("The employer data makes the stakes concrete. According to the NACE Job Outlook 2025, nearly 90% of recruiters actively screen for problem-solving and nearly 80% for teamwork \u2014 not as soft preferences but as primary filters when reviewing new-graduate candidates. By the Job Outlook 2026 cycle, 70% of employers were using skills-based hiring (up from 65%), while the proportion still relying on GPA had fallen to 42% \u2014 down from 73% in 2019. What employers are buying, increasingly, is demonstrated collaborative capability. GPA is not a proxy for it."),
  H.pp("The workforce trajectory amplifies this. The World Economic Forum\u2019s *Future of Jobs Report 2025* projects that 39% of workers\u2019 existing skill sets will be transformed or rendered obsolete by 2030. The skills rising to fill that gap \u2014 analytical thinking, creative reasoning, resilience, flexibility \u2014 are precisely the outputs of environments where students must negotiate across disciplines under real constraints. Credentials alone do not build them. Cross-functional project experience does."),

  H.h2("The Labor-Market Premium on Hybrid Skills"),
  H.pp("There is a documented labor-market premium on professionals who can inhabit multiple roles. Burning Glass Technologies\u2019 *The Hybrid Job Economy* (2019) found that roles at the intersection of design and development grow at approximately twice the rate of the overall job market and command 20\u201340% higher compensation. These roles do not require mastery of two disciplines simultaneously; they require what IDEO CEO Tim Brown called the T-shape: disciplinary depth plus \u201Cthe disposition for collaboration across disciplines.\u201D Without the latter, Brown observed, \u201Cyou get gray compromises where the best you can achieve is the lowest common denominator.\u201D"),

  H.h2("The Direct Pedagogical Precedent"),
  H.pp("Peer-reviewed research on interdisciplinary CS-and-design education at the postsecondary level confirms that the structural challenge is solvable. Heines, Jeffers, and Kuhn\u2019s \u201CPerformamatics\u201D series (*International Journal of Learning*, 2008; ACM SIGCSE, 2009) documented outcomes from pairing Computer Science and Design Arts students in joint projects at UMass Lowell, demonstrating measurable gains in motivation and engagement. McDonald and Wolfe\u2019s work at DePaul (*Journal of Computing Sciences in Colleges*, 2008) noted that \u201Cworking effectively as a member of an interdisciplinary team is a skill highly valued by today\u2019s employers,\u201D and built an interdisciplinary capstone accordingly. At scale, Georgia Tech\u2019s Junior Design sequence (Hutter, Lawrence, McDaniel & Murrell, ACM SIGCSE, 2018), serving 400\u2013600 CS students per semester, found that genuine integration \u2014 rather than parallel disciplinary labor \u2014 results in \u201Ca smoother end product,\u201D because the disciplines are allowed to inform each other rather than run in separate lanes."),
  H.pp("As institutions that have already made this investment continue to report stronger student outcomes and employer reception, programs without structured cross-disciplinary capstone experience are asking their graduates to learn in their first job what their peers learned in their last semester of school. This initiative was built on the premise that the institution\u2019s students deserve better than that starting position."),

  H.h1("The Design Problem"),
  H.pp("The default state for cross-departmental collaboration in higher education is informal coordination: instructors agree in principle, students are told to work together, and friction resolves itself \u2014 or it does not, and projects absorb the consequences late in the semester. That default state fails reliably and for predictable reasons:"),
  H.bullet("Departments run on different milestone schedules, so deliverable timing never quite aligns."),
  H.bullet("Disciplinary terminology diverges in ways neither party recognizes until handoffs break."),
  H.bullet("Ownership of shared deliverables is ambiguous, so each side waits for the other."),
  H.bullet("Collaboration quality is either not assessed at all, or assessed only as part of a product grade that obscures whether the team actually functioned."),
  H.pp("The failure modes here are not character flaws \u2014 they are structural deficiencies, and the industry literature on design\u2013development collaboration identifies the same pathologies in professional teams. Nielsen Norman Group\u2019s \u201CCreating Design Specs for Development\u201D (2025) describes the absence of formal documentation as the source of \u201Cconfusion and frustration in design and development teams\u201D that would be preventable with what NN/g terms a \u201Ccontract between design and development.\u201D The Interaction Design Foundation\u2019s 2026 handoff curriculum catalogs the most common professional failures: vague specifications, disorganized files, missing edge-case documentation, and an over-the-wall mentality in which design and development treat each other as sequential rather than collaborative."),
  H.pp("These are exactly the failure modes students encounter when collaboration structure is not built into the course. Naming them as industry defects \u2014 not just student shortcomings \u2014 is part of what makes this framework pedagogically honest."),

  H.h1("Framework Architecture"),
  H.pp("The framework is organized around one insight: structure does not constrain creativity; it creates the conditions in which creativity can be delivered reliably."),

  H.h2("Role Clarity \u2014 The GREY Clearance Model"),
  H.pp("Within the AlgoCratic Futures project context, Graphic Design students were designated GREY clearance \u2014 a cross-functional specialist role operating within the same project structure as CS teams but under a distinct operational mandate. This framing solved the most persistent problem in cross-disciplinary collaboration: role ambiguity."),
  H.pp("When roles are vague, students default to either avoidance (waiting for the other party to define the work) or collision (overlapping efforts, conflicting directions). The GREY designation did four structural things:"),
  H.numbered("Established design students as specialized consultants with defined deliverables \u2014 not subordinate support, not passive recipients."),
  H.numbered("Positioned the Creative Brief as a formal work order between professional roles, creating mutual accountability."),
  H.numbered("Integrated both departments into the same Scrum milestone structure, so neither operated on an external or implicit schedule."),
  H.numbered("Brought design students into CS Scrum ceremonies \u2014 standups, sprint planning, sprint reviews, retrospectives \u2014 as full participants."),
  H.pp("This approach mirrors how professional cross-functional teams actually operate. The Scrum Alliance defines cross-functional teams as those whose members \u201Ccan include developers, testers, designers, and any other roles required to achieve the sprint goal\u201D \u2014 an explicit acknowledgment that design is not external to the development process. The U.S. Digital Service TechFAR Hub guidance reinforces this: federal agile teams are now expected to be cross-functional by default."),

  H.h2("Deliverable 1 \u2014 The Standardized Creative Brief Process"),
  H.pp("**Documentation created:** `26SP_Cross_Discipline_Protocol.md`"),
  H.pp("The Creative Brief process formalized a staged exchange between CS teams and GRD students across three document types:"),
  H.bullet("**Product Brief** (CS \u2192 GRD): project context, user personas, design requirements."),
  H.bullet("**Technical Brief** (CS \u2192 GRD): constraints, asset formats, integration specifications."),
  H.bullet("**Design Brief Response** (GRD \u2192 CS): concept proposals, mockup iterations, delivery specifications."),
  H.pp("**Process sequence:**"),
  H.table([
    ["Stage", "Event", "Timing"],
    ["Sprint 0, Week 2", "CS team submits Product and Technical Briefs", "—"],
    ["Sprint 0, Week 3", "GRD student submits clarifying questions", "—"],
    ["Sprint 0, Week 4", "CS team refines brief with answers", "—"],
    ["Sprint 1, Week 1", "GRD student delivers concept mockups", "—"],
    ["Sprint 1, Week 2", "CS team provides integration feedback", "—"],
    ["Sprint 1, Weeks 3–4", "GRD student delivers production assets", "—"],
  ], [2400, 4960, 2000]),
  H.pp("**Why this structure maps to industry norms.** NN/g\u2019s framing of design specifications as a \u201Ccontract\u201D between teams is not metaphorical \u2014 it reflects how high-functioning product teams assign accountability. When a student can point to a brief they submitted, a question they asked, and an asset they delivered to specification, they are rehearsing the documentation habits professional product teams depend on. They are also generating the paper trail that allows assessment to be specific rather than impressionistic."),
  H.pp("**Previous state:** Each CS / GRD pairing negotiated its own process, with no standardized artifacts and no baseline for evaluation."),
  H.pp("**Current state:** A documented protocol with clear handoffs, defined deliverable formats, and a repeatable sequence."),

  H.h2("Deliverable 2 \u2014 Three Formal Touchpoints"),
  H.pp("**Documentation created:** `26SP_Platform_Project_Matrix.md`"),
  H.pp("Milestones do more than mark time \u2014 they convert vague expectations into specific commitments. Industry project management converges on the principle that milestones must define \u201Cwhat \u2018done\u2019 looks like at various intervals\u201D to shift teams from activity-based to outcome-based execution. In interdisciplinary student teams, this distinction is particularly consequential: activity is easy to perform and easy to confuse with progress. Milestones prevent that confusion."),

  H.h3("Touchpoint 1 \u2014 Creative Brief Exchange (End of Sprint 0)"),
  H.pp("Both parties have committed deliverables: CS submits product and technical briefs; GRD submits concept questions. The assessment criterion at this stage is brief completeness and clarity. The outcome is a shared, documented understanding of project vision and constraints \u2014 replacing the assumption of alignment with evidence of it."),

  H.h3("Touchpoint 2 \u2014 Concept Review and Iteration (Sprint 1, Weeks 1\u20132)"),
  H.pp("GRD presents initial mockups. CS provides integration feedback and technical feasibility assessment. A joint design critique establishes approved direction. The assessment criterion at this stage is communication quality and iteration responsiveness \u2014 capturing the collaboration behavior, not just the artifact. The outcome is an approved design direction with technical validation on record."),

  H.h3("Touchpoint 3 \u2014 Asset Delivery and Integration (Sprint 1, Weeks 3\u20134)"),
  H.pp("GRD delivers production-ready assets to specification. CS integrates them into a working application. Both parties co-present at the Graduate Showcase. Assessment criteria at this stage include technical integration success and design implementation fidelity \u2014 measuring whether the collaboration produced a coherent whole rather than two well-executed halves that do not quite fit together."),

  H.pp("**Integration with Scrum ceremonies.** Design students participated in daily async standups, Sprint 1 planning, the Graduate Showcase Sprint Review, and a cross-departmental retrospective. This is the same ceremony structure Mahni\u010D documented in his longitudinal Scrum capstone study (*IEEE Transactions on Education*, 2012), which found that these ceremonies produced \u201Coverwhelmingly positive\u201D student outcomes with measurable improvements in planning and estimation \u2014 outcomes students explicitly linked to their employability."),

  H.h2("Deliverable 3 \u2014 Collaboration Rubrics"),
  H.pp("**Documentation created:** `Pitch_Presentation_Rubric.md`"),
  H.pp("The rubric is where good intentions about collaboration become assessable commitments. The principle underlying the design is straightforward: if collaboration behaviors are not separately measured, they are not taught. Students learn to optimize for what gets scored. A rubric that only evaluates individual deliverable quality is, functionally, a rubric that treats collaboration as optional."),
  H.pp("The research supports this design choice. The Interprofessional Collaborator Assessment Rubric (Curran et al., grounded in the WHO 2010 *Framework for Action on Interprofessional Education & Collaborative Practice*) is the most-cited validated instrument of this type, and its architecture \u2014 assessing collaboration as a competency in its own right \u2014 is directly applicable here. A 2024 meta-analysis by Panadero et al. (*Educational Psychology Review*) found a moderate positive effect (g = 0.45) of rubric use on academic performance, with the effect strongest when criteria are explicit and distributed in advance."),
  H.pp("**Rubric structure:**"),
  H.table([
    ["Category", "Points", "What It Measures"],
    ["Communication Quality", "20", "Clarity of briefs, responsiveness, professionalism, documentation completeness"],
    ["Deliverable Integration", "25", "Technical spec adherence, asset quality, integration success, fidelity"],
    ["Collaboration Process", "20", "Milestone adherence, iteration responsiveness, problem-solving approach"],
    ["Final Product Quality", "35", "UX enhancement, professional polish, technical implementation, completeness"],
  ], [2880, 1120, 5360]),
  H.pp("This three-axis structure \u2014 individual craft, collaboration behaviors, integration quality \u2014 directly addresses the dominant failure mode of group projects in higher education: one student absorbs the load while others contribute minimally. When collaboration behaviors carry 20 points and are assessed against concrete criteria (Was the brief complete? Were questions responded to within the milestone window? Did the team adapt when problems arose?), there is no longer a grade structure that rewards passengers."),

  H.h1("Results \u2014 Graduate Showcase, May 2026"),
  H.pp("**Quantitative outcomes:**"),
  H.bullet("5 CS capstone teams paired with GRD students across the full semester"),
  H.bullet("5 completed projects with integrated, professional-quality design assets"),
  H.bullet("100% milestone completion across all five pairings"),
  H.bullet("Average collaboration rubric score: **87 / 100**"),
  H.pp("**Qualitative outcomes:**"),
  H.bullet("CS teams reported that design integration substantially improved perceived project quality."),
  H.bullet("GRD students reported meaningful gains in understanding technical constraints and iterative feedback processes."),
  H.bullet("Both cohorts identified the formal handoff structure as the element most responsible for reducing last-minute communication crises."),
  H.bullet("Both departments expressed interest in continuing the protocol for subsequent terms."),
  H.pp("**What the Graduate Showcase demonstrated to external stakeholders:** Faculty, industry partners, and fellow students encountered polished, professionally integrated web applications \u2014 not student prototypes that looked like student prototypes. That visible quality gap between AlgoCratic Futures projects and typical capstone output is the observable return on the structural investment described above."),

  H.h1("Institutional Value"),

  H.h2("A Replicable Framework"),
  H.pp("The protocols created here are not semester-specific documentation \u2014 they are reusable infrastructure. When a process is documented once and works, the cost of repeating it falls dramatically. When it fails in some respect, the documentation makes the failure diagnosable and correctable rather than mysterious."),
  H.bullet("**Spring 2026:** First full implementation (completed)."),
  H.bullet("**Fall 2026:** Protocol refinement based on retrospective feedback."),
  H.bullet("**Future terms:** Standardized framework with embedded continuous improvement."),

  H.h2("A Template for Adjacent Collaborations"),
  H.pp("The structured collaboration approach is now available as a model for other cross-departmental pairings the institution may pursue:"),
  H.bullet("Web Development + Graphic Design partnerships"),
  H.bullet("Database courses + Business Analytics integration"),
  H.bullet("Mobile Development + User Experience research"),
  H.pp("Any program pairing where disciplinary handoffs are the primary design challenge can adopt this framework\u2019s milestone structure, brief protocol, and rubric architecture without building from scratch."),

  H.h2("Career Readiness in the Language Employers Use"),
  H.pp("The NACE Career Readiness framework identifies eight core competencies employers expect from new graduates. The framework developed here directly develops four: Teamwork/Collaboration, Professionalism/Work Ethic, Critical Thinking/Problem Solving, and Communication \u2014 the four in which the NACE 2024 Student Survey vs. Job Outlook 2025 comparison reveals the largest perception gaps between student self-assessment and employer rating. Students routinely overestimate their proficiency in these areas because they have never been assessed against them with specificity."),
  H.pp("What this capstone framework does, structurally, is close that gap before graduation rather than after it. When students leave the institution having written a formal brief, delivered it on a milestone schedule, received structured feedback from an external collaborator, integrated that feedback into a working product, and had their collaboration behaviors scored against explicit criteria \u2014 they have done the work. That is what the rubric measures. That is what the Graduate Showcase makes visible."),

  H.h1("Conclusion \u2014 Objective Exceeded"),
  H.pp("**Minimum requirement:** Document Creative Brief process, establish three touchpoints, create collaboration rubrics."),
  H.pp("**Actual delivery:**"),
  H.bullet("Comprehensive cross-departmental framework with full process documentation."),
  H.bullet("Milestone structure integrated with Scrum methodology and Scrum Alliance cross-functional team norms."),
  H.bullet("Multi-dimensional assessment rubric with empirical grounding in collaboration-competency literature."),
  H.bullet("Successful first implementation with five completed, publicly presented projects."),
  H.bullet("Replicable protocol positioned for institutional reuse and adjacent-program adoption."),
  H.pp("The research had already established that this approach works. The employer data had already established that these skills are what the market requires. What remained was the institutional will to build the framework and the execution discipline to make it run. Both are now demonstrated."),
];

// -------------------- SUPPORTING RESEARCH --------------------
const research = [
  ...H.buildDivider({
    eyebrow: "PART B",
    title: "Supporting Evidence Base",
    subtitle: "Research foundation for the cross-departmental capstone framework",
  }),

  H.h1("Supporting Evidence Base"),
  H.pp("This section presents the convergent research base on which the Objective 1 framework was built. The framework is supported by peer-reviewed CS-education research (ACM SIGCSE, *IEEE Transactions on Education*, *Journal of Computing Sciences in Colleges*), national employer surveys (NACE Job Outlook 2025/2026; WEF *Future of Jobs Report 2025*), labor-market analytics (Burning Glass / Lightcast on hybrid jobs), and practitioner authorities (Nielsen Norman Group, IDEO, Agile Alliance, Scrum Alliance, AAC&U). Every structural element of the framework maps onto a documented best practice."),

  H.h2("Summary of Key Findings"),
  H.numbered("**Interdisciplinary CS + design capstones are an established, peer-reviewed pedagogical model.** Direct precedents include Heines, Jeffers & Kuhn\u2019s \u201CPerformamatics\u201D (*International Journal of Learning*, 2008) and McDonald & Wolfe (*Journal of Computing Sciences in Colleges*, 2008). Georgia Tech\u2019s CS Junior Design sequence (SIGCSE \u201918) provides a large-scale model demonstrating that genuine integration produces \u201Ca smoother end product.\u201D"),
  H.numbered("**Agile / Scrum in capstone courses produces industry-aligned outcomes.** Mahni\u010D\u2019s longitudinal study (*IEEE Transactions on Education*, 2012) reports overwhelmingly positive student perceptions tied explicitly to employability."),
  H.numbered("**Structured creative briefs and formal handoff documentation are industry norms that reduce error and rework.** Nielsen Norman Group, the Interaction Design Foundation, and Agile Alliance converge on this consensus."),
  H.numbered("**Milestone-based collaboration improves accountability, transparency, and completion.** Industry project-management practice (Atlassian, Teamwork.com) and the Scrum / agile literature support milestone structure as the primary mechanism for outcome-based execution."),
  H.numbered("**Shared rubrics that assess collaboration (not just individual deliverables) have established validity in interprofessional education.** The Interprofessional Collaborator Assessment Rubric (Curran et al., grounded in WHO 2010) is the most-cited validated instrument; rubric meta-analysis (Panadero et al. 2024) shows g = 0.45 effect on academic performance."),
  H.numbered("**Employer demand for cross-functional / T-shaped graduates is documented, large, and growing.** NACE Job Outlook 2025/2026, WEF *Future of Jobs Report 2025*, Burning Glass *Hybrid Job Economy* (2019), and IDEO / Tim Brown\u2019s T-shape framework all converge here."),
  H.numbered("**Design\u2013development integration is an established industry practice with named methodologies.** Google Ventures\u2019 Design Sprint, NN/g\u2019s designer\u2013developer relationship literature, and Agile Alliance guidance all institutionalize joint design-and-development work."),
  H.numbered("**The framework satisfies AAC&U high-impact-practice criteria and community-college CTE program-review requirements.** AAC&U/Kuh recognize Capstone Courses and Collaborative Assignments as two of eleven HIPs."),

  H.h2("1. Cross-Disciplinary Project-Based Learning (CS \u00D7 Design)"),
  H.pp("**Heines, J. M., Jeffers, J., & Kuhn, S. (2008).** \u201CPerformamatics: Experiences With Connecting a Computer Science Course to a Design Arts Course.\u201D *International Journal of Learning* 15(2):9\u201316. The closest published analog to the framework: a CS course paired with a Design Arts course, with interdisciplinary teams producing joint software/performance work. The authors report that \u201Cthe impact on CS students was considerably more positive than on Art students,\u201D an empirical finding addressed in the rubric design (the three-axis structure exists in part to counter asymmetric perceived gains)."),
  H.pp("**McDonald, J. & Wolfe, R. (2008).** \u201CUsing computer graphics to foster interdisciplinary collaboration in capstone courses.\u201D *Journal of Computing Sciences in Colleges* 24(1):83\u201390 (DePaul). The course became foundational for DePaul\u2019s CS+Animation BS, with explicit alignment to industry teamwork expectations."),
  H.pp("**Hutter, L., Lawrence, H. M., McDaniel, M., & Murrell, M. (2018).** \u201CFostering Meaningful Collaboration in an Interdisciplinary Capstone Course.\u201D Panel, SIGCSE \u201918, DOI 10.1145/3159450.3159625. Documents the Georgia Tech CS Junior Design / Tech Comm sequence (CS 3311/3312 \u2194 LMC 3431/3432), serving 400\u2013600 CS students per semester."),

  H.h2("2. Structured Creative Briefs and Formal Handoff Documentation"),
  H.pp("**Nielsen Norman Group \u2014 Gordon, K. (June 2025).** \u201CCreating Design Specs for Development.\u201D Specs \u201Cprovide all relevant information needed to align the design and development teams.\u201D The article frames the development ticket as \u201Ca \u2018contract\u2019 between the dev and design teams. What is outlined in the issue is what the developer is on the hook for delivering.\u201D"),
  H.pp("**Interaction Design Foundation** (handoff curriculum, updated 2026) catalogs common handoff failures \u2014 disorganized files, vague specifications, missing prototypes, designing only for ideal scenarios \u2014 and recommends explicit error-state, empty-state, and edge-case documentation."),
  H.pp("**Implication for the capstone:** A written creative brief and a milestone-tied handoff document are not academic artifices \u2014 they are the artifacts professional teams actually produce, and the failure modes the industry literature warns about are exactly the failure modes the rubric should penalize."),

  H.h2("3. Milestone-Based Collaboration Frameworks"),
  H.pp("Project-management literature treats milestones as the principal vehicle for accountability, stakeholder communication, and outcome-based execution. Atlassian\u2019s milestone-chart guidance and Teamwork.com both emphasize that without explicit checkpoints, schedules lose meaning. In agile contexts, Agile Alliance recommends \u201Cregular touch points, such as sprint reviews or daily stand-ups,\u201D to keep cross-functional teams aligned. For student teams, milestones provide three documented benefits: a defensible basis for formative assessment, stakeholder visibility for cross-departmental faculty, and early identification of slip risk before final-deliverable failure."),

  H.h2("4. Scrum / Agile in Educational Settings"),
  H.pp("**Mahni\u010D, V. (2012).** \u201CA Capstone Course on Agile Software Development Using Scrum.\u201D *IEEE Transactions on Education* 55(1), Feb 2012, DOI 10.1109/TE.2011.2142311. The most-cited empirical study; documents Scrum-team capstones at the University of Ljubljana, with measurable progress in estimation and planning and overwhelmingly positive student perceptions tied to employability."),
  H.pp("**TechFAR Hub / U.S. Digital Service** (federal agile-team guidance): \u201Cdevelopers and tester roles should be cross-functional individuals who are able to work either position\u201D \u2014 institutional confirmation that government and industry teams expect this skill set."),

  H.h2("5. Shared and Joint Assessment Rubrics"),
  H.pp("The Interprofessional Collaborator Assessment Rubric (Curran et al., grounded in WHO 2010) is the most-cited validated example of a rubric evaluating collaboration as a competency. The rubric-effects literature \u2014 Jonsson & Svingby (*Educational Research Review*, 2007); Panadero et al. (*Educational Psychology Review*, 2024) \u2014 supports that rubrics promote student learning when criteria are made explicit in advance. The Panadero meta-analysis finds a moderate positive effect (g = 0.45)."),
  H.pp("In interdisciplinary capstones specifically, best practice is a rubric that separately scores (a) individual disciplinary craft, (b) collaboration behaviors, and (c) integration quality of the joint artifact \u2014 the exact structure adopted here."),

  H.h2("6. T-Shaped Skills and Cross-Functional Employability"),
  H.pp("**NACE Job Outlook 2025 / 2026:** problem-solving (nearly 90%), teamwork (nearly 80%), communication (>75%); 70% of employers in JO 2026 use skills-based hiring, only 42% still screen by GPA."),
  H.pp("**NACE 2024 Student Survey vs. Job Outlook 2025:** for leadership and professionalism the perception gap exceeds or approaches 30 percentage points; for critical thinking and communication it is roughly 25 points \u2014 making structured cross-functional projects with formal feedback particularly valuable for community-college students."),
  H.pp("**WEF *Future of Jobs Report 2025*** (Jan 2025): \u201CAnalytical thinking remains the most sought-after core skill among employers, with seven out of 10 companies considering it as essential in 2025\u2026\u201D WEF projects 39% skill churn between 2025 and 2030."),
  H.pp("**Burning Glass / Lightcast, *The Hybrid Job Economy* (2019):** hybrid roles grow at ~2\u00D7 the rate of the overall job market and pay 20\u201340% more. \u201CThe skills that drive hybridization fall into five key skill areas: Big Data and Analytics; Intersection of Design and Development; Sales and Customer Service; Emerging Digital Technologies; Evolving Compliance and Regulatory Landscape.\u201D"),
  H.pp("**IDEO / Tim Brown** popularized the T-shape: depth in a discipline plus \u201Cthe disposition for collaboration across disciplines\u201D \u2014 without which \u201Cyou get gray compromises where the best you can achieve is the lowest common denominator.\u201D"),

  H.h2("7. Design\u2013Development Integration in Professional Software Teams"),
  H.pp("**Google Ventures Design Sprint** (Knapp, 2010; *Sprint*, Simon & Schuster, 2016): a five-day cross-functional process now used at Google, Slack, Airbnb, Uber, LEGO, the *New York Times*, Stanford, Harvard Business School, and the United Nations."),
  H.pp("**Scrum Alliance** (cross-functional team glossary): \u201CCross-functional team members can include developers, testers, designers, and any other roles required to achieve the sprint goal.\u201D"),
  H.pp("**NN/g** (\u201CRedefine Your Design Skills to Prepare for AI,\u201D 2024) forecasts that \u201CAI-powered tools will extend teams\u2019 capabilities beyond traditional boundaries. Designers will do data analysis, developers will craft UIs, and analysts will write code\u201D \u2014 reinforcing the strategic value of cross-functional fluency."),

  H.h2("8. Institutional and Accreditation Alignment"),
  H.pp("**AAC&U High-Impact Practices** (Kuh, 2008; Kuh & O\u2019Donnell, 2013): Capstone Courses and Projects and Collaborative Assignments and Projects are two of eleven HIPs with documented effects on retention, learning gains, and equity outcomes. Kuh\u2019s eight quality elements (high performance expectations, significant time/effort, substantive interactions, interactions with diversity, frequent and constructive feedback, periodic structured reflection, real-world application, public demonstration of competence) are essentially the design specification of a well-run cross-departmental capstone."),
  H.pp("**Community-College CTE program review** (Iowa CTE Program Review Toolkit, July 2025; California CTE State Plan): explicitly requires programs to describe \u201Cinterdisciplinary learning opportunities, such as collaboration between different departments or fields of study, to reflect the integrated nature of many modern\u201D workplaces, and to use \u201Cperformance-based assessments (e.g., portfolios, simulations, capstone projects).\u201D"),

  H.h2("Caveats and Boundary Conditions"),
  H.pp("The strongest direct empirical pairing studies (Heines et al. 2008; McDonald & Wolfe 2008) are mixed-methods accounts of single-institution implementations, not large-n quantitative trials. The peer-reviewed CS-education literature on interdisciplinary capstones is largely composed of such accounts, plus the broader engineering-capstone literature. The evidence here should be read as a convergent best-practice consensus rather than as a randomized causal claim."),
  H.pp("Heines et al.\u2019s finding that CS students perceived more gains than design students is a known risk for this framework. The three-column rubric and balanced milestone deliverables described in Part A are the explicit design mitigation."),
  H.pp("NACE Job Outlook samples are modest (n=237 in 2025; n=183 in 2026) and skew toward NACE employer members. They remain the most-cited U.S. authority on entry-level hiring intent. WEF *Future of Jobs* figures are employer forecasts (\u201Cby 2030\u201D), aggregated from self-report by more than 1,000 employers \u2014 not measured workforce outcomes. The Burning Glass / Lightcast hybrid-jobs research is the work of a single private analytics firm; the most-quoted figures derive from its 2019 *Hybrid Job Economy* report. Where the binder cites these sources, it does so as the best available proxy for employer expectation, not as proof of causal pedagogical impact."),
];

// -------------------- ASSEMBLE --------------------
const doc = H.buildDoc({
  docTitle: "Objective 1 — Cross-Departmental Collaboration",
  instructorLabel: "[REDACTED]",
  sections: [
    { children: cover, noHeader: true, noFooter: true },
    { children: [...objectiveBody, ...research] },
  ],
});

H.Packer.toBuffer(doc).then(buf => {
  const outPath = '/home/claude/binder/01_Objective1_CrossDept.docx';
  fs.writeFileSync(outPath, buf);
  console.log(`Wrote ${outPath} (${buf.length} bytes)`);
});
