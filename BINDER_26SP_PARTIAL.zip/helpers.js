// helpers.js — shared style, layout, and paragraph helpers for the binder
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, PageOrientation, LevelFormat,
  TabStopType, TabStopPosition,
  HeadingLevel, BorderStyle, WidthType, ShadingType,
  VerticalAlign, PageNumber, PageBreak, SectionType
} = require('docx');

// ---------- COLORS / DESIGN TOKENS ----------
const COLOR = {
  PRIMARY: "1F3A5F",      // institutional dark navy
  ACCENT:  "4A6FA5",      // lighter navy for accents
  MUTED:   "606060",      // muted gray for subtitles
  RULE:    "B0B8C4",      // very light gray for rules
  TEXT:    "1A1A1A",      // near-black body text
  HEADERTXT: "404040",    // dark gray for header/footer
};

const FONT = "Calibri";

// ---------- PAGE / SECTION PROPERTIES ----------
const PAGE_LETTER = {
  size: { width: 12240, height: 15840 },
  margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 }
};
const CONTENT_WIDTH = 9360; // US Letter content width @ 1" margins

// ---------- STYLES ----------
const DOC_STYLES = {
  default: {
    document: { run: { font: FONT, size: 22, color: COLOR.TEXT } }, // 11pt body
  },
  paragraphStyles: [
    { id: "BigTitle", name: "Big Title", basedOn: "Normal", next: "Normal", quickFormat: true,
      run: { size: 60, bold: true, font: FONT, color: COLOR.PRIMARY },
      paragraph: { spacing: { before: 0, after: 240 }, alignment: AlignmentType.CENTER } },
    { id: "BigSubtitle", name: "Big Subtitle", basedOn: "Normal", next: "Normal", quickFormat: true,
      run: { size: 32, font: FONT, color: COLOR.MUTED },
      paragraph: { spacing: { before: 0, after: 240 }, alignment: AlignmentType.CENTER } },
    { id: "Eyebrow", name: "Eyebrow", basedOn: "Normal", next: "Normal", quickFormat: true,
      run: { size: 18, bold: true, font: FONT, color: COLOR.ACCENT, characterSpacing: 60 },
      paragraph: { spacing: { before: 0, after: 240 }, alignment: AlignmentType.CENTER } },
    { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
      run: { size: 36, bold: true, font: FONT, color: COLOR.PRIMARY },
      paragraph: { spacing: { before: 360, after: 180 }, outlineLevel: 0 } },
    { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
      run: { size: 28, bold: true, font: FONT, color: COLOR.PRIMARY },
      paragraph: { spacing: { before: 280, after: 120 }, outlineLevel: 1 } },
    { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
      run: { size: 24, bold: true, font: FONT, color: COLOR.ACCENT },
      paragraph: { spacing: { before: 220, after: 80 }, outlineLevel: 2 } },
    { id: "Heading4", name: "Heading 4", basedOn: "Normal", next: "Normal", quickFormat: true,
      run: { size: 22, bold: true, italics: true, font: FONT, color: COLOR.HEADERTXT },
      paragraph: { spacing: { before: 180, after: 60 }, outlineLevel: 3 } },
    { id: "BodyText", name: "Body Text", basedOn: "Normal", next: "Normal", quickFormat: true,
      run: { font: FONT, size: 22, color: COLOR.TEXT },
      paragraph: { spacing: { before: 0, after: 160, line: 320 } } }, // 1.15 line spacing-ish
    { id: "Caption", name: "Caption", basedOn: "Normal", next: "Normal", quickFormat: true,
      run: { font: FONT, size: 18, italics: true, color: COLOR.MUTED },
      paragraph: { spacing: { before: 0, after: 160 }, alignment: AlignmentType.CENTER } },
    { id: "BlockQuote", name: "Block Quote", basedOn: "Normal", next: "Normal", quickFormat: true,
      run: { font: FONT, size: 22, italics: true, color: COLOR.HEADERTXT },
      paragraph: { spacing: { before: 120, after: 200, line: 320 }, indent: { left: 720, right: 720 } } },
  ]
};

// ---------- NUMBERING (bullets and ordered lists) ----------
const DOC_NUMBERING = {
  config: [
    { reference: "bullets",
      levels: [
        { level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } },
                   run: { font: FONT, color: COLOR.ACCENT } } },
        { level: 1, format: LevelFormat.BULLET, text: "◦", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 1440, hanging: 360 } },
                   run: { font: FONT, color: COLOR.ACCENT } } },
      ] },
    { reference: "numbers",
      levels: [
        { level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } },
                   run: { font: FONT, bold: true, color: COLOR.PRIMARY } } },
      ] },
  ]
};

// ---------- HEADER / FOOTER FACTORIES ----------
function makeHeader(docTitle) {
  return new Header({
    children: [
      new Paragraph({
        tabStops: [{ type: TabStopType.RIGHT, position: 9360 }],
        border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: COLOR.RULE, space: 6 } },
        spacing: { after: 60 },
        children: [
          new TextRun({ text: docTitle, font: FONT, size: 18, color: COLOR.HEADERTXT, bold: true }),
          new TextRun({ text: "\t", font: FONT }),
          new TextRun({ text: "Performance Review 2025–2026", font: FONT, size: 18, color: COLOR.MUTED, italics: true }),
        ],
      }),
    ],
  });
}

function makeFooter(instructorLabel) {
  return new Footer({
    children: [
      new Paragraph({
        tabStops: [
          { type: TabStopType.CENTER, position: 4680 },
          { type: TabStopType.RIGHT, position: 9360 },
        ],
        border: { top: { style: BorderStyle.SINGLE, size: 6, color: COLOR.RULE, space: 6 } },
        spacing: { before: 60 },
        children: [
          new TextRun({ text: instructorLabel, font: FONT, size: 16, color: COLOR.HEADERTXT }),
          new TextRun({ text: "\t", font: FONT }),
          new TextRun({ text: "Page ", font: FONT, size: 16, color: COLOR.HEADERTXT }),
          new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 16, color: COLOR.HEADERTXT }),
          new TextRun({ text: " of ", font: FONT, size: 16, color: COLOR.HEADERTXT }),
          new TextRun({ children: [PageNumber.TOTAL_PAGES], font: FONT, size: 16, color: COLOR.HEADERTXT }),
          new TextRun({ text: "\t", font: FONT }),
          new TextRun({ text: "[REDACTED] TCC", font: FONT, size: 16, color: COLOR.MUTED }),
        ],
      }),
    ],
  });
}

// ---------- PARAGRAPH HELPERS ----------

function blank(count = 1) {
  // Empty paragraphs for vertical spacing on cover/divider pages
  const out = [];
  for (let i = 0; i < count; i++) out.push(new Paragraph({ children: [] }));
  return out;
}

function pageBreak() {
  return new Paragraph({ children: [new PageBreak()] });
}

function rule(color = COLOR.RULE, size = 6) {
  return new Paragraph({
    border: { bottom: { style: BorderStyle.SINGLE, size: size, color: color, space: 1 } },
    spacing: { before: 60, after: 120 },
    children: [],
  });
}

function accentBar(color = COLOR.PRIMARY) {
  return new Paragraph({
    border: { bottom: { style: BorderStyle.SINGLE, size: 24, color: color, space: 1 } },
    spacing: { before: 0, after: 200 },
    children: [],
  });
}

// h1, h2, h3, h4 — return Paragraph objects with the matching heading style
// Note: `heading:` already applies the matching style id, so do NOT also set `style:`.
function h1(text) { return new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun({ text })] }); }
function h2(text) { return new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun({ text })] }); }
function h3(text) { return new Paragraph({ heading: HeadingLevel.HEADING_3, children: [new TextRun({ text })] }); }
function h4(text) { return new Paragraph({ heading: HeadingLevel.HEADING_4, children: [new TextRun({ text })] }); }

// p — body paragraph from an array of run specs OR a plain string
// run spec: { t: "text", b: true, i: true, c: "color" }
function p(arg, opts = {}) {
  let runs;
  if (typeof arg === 'string') {
    runs = [new TextRun({ text: arg })];
  } else if (Array.isArray(arg)) {
    runs = arg.map(r => {
      if (typeof r === 'string') return new TextRun({ text: r });
      return new TextRun({
        text: r.t,
        bold: r.b || false,
        italics: r.i || false,
        color: r.c || undefined,
        font: r.font || FONT,
      });
    });
  } else {
    runs = [new TextRun({ text: String(arg) })];
  }
  return new Paragraph({
    style: opts.style || "BodyText",
    alignment: opts.alignment || undefined,
    spacing: opts.spacing || undefined,
    children: runs,
  });
}

// Mini-markdown parser for inline **bold** and *italic*
// Returns an array of run specs suitable for p([...])
function mdRuns(text) {
  const out = [];
  // Tokenize on **bold** and *italic* (very simple, no nesting)
  const re = /(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)/g;
  let last = 0;
  let m;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) out.push({ t: text.slice(last, m.index) });
    const tok = m[1];
    if (tok.startsWith('**')) out.push({ t: tok.slice(2, -2), b: true });
    else if (tok.startsWith('`')) out.push({ t: tok.slice(1, -1), font: "Consolas" });
    else out.push({ t: tok.slice(1, -1), i: true });
    last = re.lastIndex;
  }
  if (last < text.length) out.push({ t: text.slice(last) });
  return out;
}

// pp — paragraph from a markdown-ish string (handles **bold**, *italic*, `code`)
function pp(text, opts = {}) {
  return p(mdRuns(text), opts);
}

// Bullet item: text may include inline markdown
function bullet(text, level = 0) {
  return new Paragraph({
    numbering: { reference: "bullets", level: level },
    spacing: { before: 60, after: 60, line: 300 },
    children: typeof text === 'string'
      ? mdRuns(text).map(r => new TextRun({ text: r.t, bold: r.b, italics: r.i, font: r.font || FONT, color: r.c || COLOR.TEXT }))
      : text,
  });
}

function numbered(text, level = 0) {
  return new Paragraph({
    numbering: { reference: "numbers", level: level },
    spacing: { before: 60, after: 60, line: 300 },
    children: typeof text === 'string'
      ? mdRuns(text).map(r => new TextRun({ text: r.t, bold: r.b, italics: r.i, font: r.font || FONT, color: r.c || COLOR.TEXT }))
      : text,
  });
}

// Block quote
function quote(text) {
  return new Paragraph({
    style: "BlockQuote",
    children: typeof text === 'string'
      ? mdRuns(text).map(r => new TextRun({ text: r.t, bold: r.b, italics: r.i || true, font: r.font || FONT, color: COLOR.HEADERTXT }))
      : text,
  });
}

// ---------- TABLE HELPER ----------
// rows: [[cellText, cellText, ...], ...] where first row is treated as header by default
// columnWidths: array of DXA widths, must sum to CONTENT_WIDTH
function table(rows, columnWidths, opts = {}) {
  const totalWidth = columnWidths.reduce((a, b) => a + b, 0);
  const headerFill = opts.headerFill || "E8EEF6";
  const border = { style: BorderStyle.SINGLE, size: 4, color: COLOR.RULE };
  const borders = { top: border, bottom: border, left: border, right: border, insideHorizontal: border, insideVertical: border };

  const trs = rows.map((row, rIdx) => {
    const isHeader = rIdx === 0 && opts.noHeader !== true;
    return new TableRow({
      tableHeader: isHeader,
      children: row.map((cellContent, cIdx) => {
        // cellContent can be a string (single paragraph) or array of Paragraphs
        let children;
        if (typeof cellContent === 'string') {
          const runs = mdRuns(cellContent).map(r => new TextRun({
            text: r.t,
            bold: r.b || isHeader,
            italics: r.i || false,
            font: r.font || FONT,
            size: 20,
            color: isHeader ? COLOR.PRIMARY : COLOR.TEXT,
          }));
          children = [new Paragraph({ children: runs, spacing: { before: 40, after: 40 } })];
        } else if (Array.isArray(cellContent)) {
          children = cellContent;
        } else {
          children = [cellContent];
        }
        return new TableCell({
          borders,
          width: { size: columnWidths[cIdx], type: WidthType.DXA },
          shading: isHeader ? { fill: headerFill, type: ShadingType.CLEAR } : undefined,
          margins: { top: 100, bottom: 100, left: 140, right: 140 },
          children,
        });
      }),
    });
  });

  return new Table({
    width: { size: totalWidth, type: WidthType.DXA },
    columnWidths,
    rows: trs,
  });
}

// ---------- COVER PAGE BUILDER ----------
function buildCoverPage(opts) {
  // opts: { eyebrow, title, subtitle, metadata: [{label, value}, ...], dateLine }
  const out = [];
  out.push(...blank(2));
  out.push(accentBar(COLOR.PRIMARY));
  out.push(new Paragraph({
    style: "Eyebrow",
    children: [new TextRun({ text: opts.eyebrow, characterSpacing: 80, bold: true })],
  }));
  out.push(...blank(3));
  out.push(new Paragraph({ style: "BigTitle", children: [new TextRun({ text: opts.title })] }));
  if (opts.subtitle) {
    out.push(new Paragraph({ style: "BigSubtitle", children: [new TextRun({ text: opts.subtitle })] }));
  }
  out.push(...blank(4));
  out.push(rule(COLOR.ACCENT, 8));

  // Metadata table — two columns, left labels right values
  if (opts.metadata && opts.metadata.length) {
    const metaRows = opts.metadata.map(m => [m.label, m.value]);
    out.push(table(metaRows, [3120, 6240], { noHeader: true }));
  }
  out.push(rule(COLOR.ACCENT, 8));
  out.push(...blank(3));
  if (opts.dateLine) {
    out.push(new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: opts.dateLine, font: FONT, size: 20, italics: true, color: COLOR.MUTED })],
    }));
  }
  return out;
}

// ---------- SECTION DIVIDER (full-page lead page) ----------
// Renders as a standalone page: forces a page break before AND after,
// so body content following the divider always starts on a fresh page.
function buildDivider(opts) {
  // opts: { eyebrow, title, subtitle, leadingBreak (default true), trailingBreak (default true) }
  const out = [];
  if (opts.leadingBreak !== false) out.push(pageBreak());
  out.push(...blank(6));
  out.push(accentBar(COLOR.ACCENT));
  out.push(new Paragraph({
    style: "Eyebrow",
    children: [new TextRun({ text: opts.eyebrow, characterSpacing: 80, bold: true })],
  }));
  out.push(...blank(2));
  out.push(new Paragraph({
    style: "BigTitle",
    children: [new TextRun({ text: opts.title, size: 56 })],
  }));
  if (opts.subtitle) {
    out.push(new Paragraph({
      style: "BigSubtitle",
      children: [new TextRun({ text: opts.subtitle, size: 28, italics: true })],
    }));
  }
  out.push(...blank(2));
  out.push(rule(COLOR.ACCENT, 8));
  if (opts.trailingBreak !== false) out.push(pageBreak());
  return out;
}

// ---------- DOCUMENT WRAPPER ----------
// buildDoc({ docTitle, instructorLabel, frontSection, bodySections }) — returns a Document
function buildDoc({ docTitle, instructorLabel, sections }) {
  return new Document({
    creator: "[REDACTED]",
    title: docTitle,
    styles: DOC_STYLES,
    numbering: DOC_NUMBERING,
    sections: sections.map(sec => ({
      properties: {
        page: PAGE_LETTER,
        ...(sec.titlePage ? { titlePage: true } : {}),
        type: sec.continuous ? SectionType.CONTINUOUS : SectionType.NEXT_PAGE,
      },
      headers: sec.noHeader ? undefined : { default: makeHeader(docTitle) },
      footers: sec.noFooter ? undefined : { default: makeFooter(instructorLabel) },
      children: sec.children,
    })),
  });
}

module.exports = {
  // docx exports for convenience
  Document, Packer, Paragraph, TextRun, AlignmentType, PageBreak,
  // design tokens
  COLOR, FONT, PAGE_LETTER, CONTENT_WIDTH,
  // styles/numbering
  DOC_STYLES, DOC_NUMBERING,
  // builders
  makeHeader, makeFooter, buildCoverPage, buildDivider, buildDoc,
  // paragraph helpers
  blank, pageBreak, rule, accentBar,
  h1, h2, h3, h4, p, pp, mdRuns, bullet, numbered, quote, table,
};
