// build_02_obj2.js — Objective 2: Ghost Student Discovery Tool
const fs = require('fs');
const H = require('./helpers');

// -------------------- COVER PAGE --------------------
const cover = H.buildCoverPage({
  eyebrow: "FILE 03 OF 05 · PERFORMANCE REVIEW BINDER",
  title: "Objective 2",
  subtitle: "Ghost Student Discovery Tool",
  metadata: [
    { label: "Classification", value: "Special Project Contribution (Cross-Functional)" },
    { label: "Department", value: "Computer & Information Technology / Programming · Platform Team" },
    { label: "Review Period", value: "July 1, 2025 – June 30, 2026" },
    { label: "Status", value: "Tool shipped May 2026" },
  ],
  dateLine: "Documentation: Objective Statement + Contribution Summary + Supporting Research",
});

// -------------------- OBJECTIVE DOCUMENTATION --------------------
const objectiveBody = [
  ...H.buildDivider({
    eyebrow: "PART A",
    title: "Objective Documentation",
    subtitle: "Project management contribution to a cross-functional tool delivery",
    leadingBreak: false,
  }),

  H.h1("Attribution Statement"),
  H.pp("Before describing the objective in detail, the scope of the instructor\u2019s contribution to the Ghost Student Discovery Tool is stated plainly:"),
  H.pp("**Implementation credit for the Ghost Student Discovery Tool belongs to colleagues H. Seidi and M. Milstead**, who wrote the software. The instructor\u2019s contribution to the project was in a project-management capacity \u2014 requirements gathering from institutional stakeholders, planning and obstacle resolution during the build cycle, and advocacy for Scrum / GitHub workflow as the project\u2019s mandatory development standard. The documentation that follows describes that project-management contribution specifically. The institutional value of the tool itself, while real and substantial, is the work of the developers; this objective documents the supporting role that helped that work ship on schedule."),

  H.h1("Objective Statement"),
  H.pp("**Specific.** Provide project management support for the development and delivery of the Ghost Student Discovery Tool \u2014 an internal fraud-detection utility targeting fraudulent enrollment and financial aid abuse \u2014 by gathering and documenting customer requirements from stakeholder departments, identifying and resolving planning and technical obstacles during the development cycle, and establishing a Scrum / GitHub workflow as a non-optional project standard."),
  H.pp("**Measurable.** The tool shipped in May 2026. Three discrete contribution areas were verified by the development team:"),
  H.numbered("Customer requirements gathering and documentation."),
  H.numbered("Assistance with project planning and resolution of technical obstacles."),
  H.numbered("Advocacy and enforcement of Scrum methodology and GitHub-based workflow as the mandatory development process."),
  H.pp("**Achievable.** This objective fell within the scope of the Platform Team\u2019s mission to provide enabling tooling and process infrastructure across the institution. The contribution operated in a supporting project-management capacity alongside the development team, consistent with the Team Topologies \u201Cplatform team\u201D model already adopted by the department."),
  H.pp("**Relevant.** The Ghost Student Discovery Tool directly addresses a documented institutional and systemic risk. The evidence base in Part B establishes both the severity of the threat in this region and the alignment of this tool with federal, state, and industry responses to the crisis."),
  H.pp("**Time-bound.** The tool shipped in May 2026, coinciding with the federal compliance timeline established by the U.S. Department of Education\u2019s mid-2025 identity-verification mandates and ahead of the Fall 2026 enrollment cycle."),

  H.h1("Why This Work Was Worth Doing"),

  H.h2("The Regional Threat Is Severe and Actively Prosecuted"),
  H.pp("The largest ghost-student fraud prosecution in North Carolina history was sentenced in June 2025 \u2014 a Fayetteville-based scheme that generated over $4.7 million in fraudulent financial aid awards across multiple NC community colleges, including the institution under review. The perpetrator recruited approximately 80 individuals whose identities were used to submit fraudulent admissions applications and FAFSAs. Over $3.5 million was actually disbursed before the scheme was detected. *(Sources: CBS17, June 2025; DOJ Eastern District of NC press releases; ABC11 Raleigh-Durham, January 2026.)*"),
  H.pp("A second NC prosecution involved a Clayton man sentenced to 53 months for stealing over $400,000 using stolen identities at multiple colleges. A third case \u2014 a Cumberland County resident \u2014 involved fabricated high-school transcripts used to enroll unqualified individuals in Wake Tech online programs. The U.S. Attorney for the Eastern District of NC confirmed in January 2026 that **multiple additional investigations remain active** in the district. *(Sources: DOJ EDNC, January 2023 and the Cumberland County indictment; ABC11, January 2026.)*"),

  H.h2("The National Scale Dwarfs Individual Cases"),
  H.pp("The Department of Education\u2019s Office of Inspector General maintains more than 200 open investigations into ghost-student schemes nationally, with investigated fraud exceeding $350 million over five years \u2014 a figure OIG officials describe as a fraction of the true total. In 2025, the DOE reported preventing $1 billion in fraudulent student-loan payments after enhanced screening flagged approximately 150,000 suspect identities in a single week. *(Sources: WJLA I-Team investigation, 2025; U.S. Department of Education press releases, June 2025.)*"),

  H.h2("Community Colleges Are the Primary Target"),
  H.pp("Ghost-student schemes exploit structural features specific to community colleges: open-enrollment admissions with no application fees, low tuition that maximizes cash refunds from Pell Grants (up to ~$7,400/year), asynchronous online courses requiring no physical presence, and minimal identity verification at the point of enrollment. Automation has amplified the problem \u2014 one institution reported receiving 50 fraudulent applications within two seconds. *(Sources: Carahsoft / HUMAN Security, 2025; AACRAO guidance document; IntelliBoard, 2025.)*"),

  H.h2("The Institution\u2019s Home Region Is Specifically Implicated"),
  H.pp("The Melvin prosecution directly named the institution as one of the victimized colleges. The perpetrator operated from the surrounding metropolitan area and recruited straw students from the local county. This is not an abstract or distant threat \u2014 it is a documented, prosecuted attack on this institution\u2019s enrollment and financial aid systems. *(Sources: CBS17, June 2025; WECT, June 2025; Old North News, June 2025.)*"),

  H.h2("Peer Institutions That Deployed Detection Tools Saw Dramatic Results"),
  H.pp("Schools that adopted AI-powered fraud screening and identity verification have documented transformative outcomes:"),
  H.bullet("**Virginia Community College System** reduced fraudulent applications from 15% of all submissions to under 1% after implementing ID verification in 2024."),
  H.bullet("**Santiago Canyon College (CA)** detected and removed 8,000 fraudulent enrollments after deploying LightLeap.AI; the following semester, 7,500 real students reclaimed those seats."),
  H.bullet("**Delaware County Community College (PA)** went from 500+ ghost students in 2023 to just 2 in 2025 after deploying the S.A.F.E. screening platform."),
  H.bullet("Across 500,000+ applications processed by LightLeap, the tool identified 79,016 fraudulent submissions \u2014 roughly twice the number caught by human staff alone."),
  H.pp("*(Sources: EDUCAUSE Review, February 2025; EdSource, 2025; Fortune, July 2025; AMSA Connect, 2025.)*"),

  H.h2("Federal Mandates Now Require Action"),
  H.pp("Effective Summer 2025, the U.S. Department of Education implemented mandatory identity verification for flagged FAFSA applicants at all Title IV institutions, including photo-ID requirements compliant with NIST IAL-2 standards. A permanent centralized screening process launched for Fall 2025, flagging approximately 300,000 applications for enhanced verification. The DOE also resumed cross-referencing student aid records against the Social Security Death Index, immediately identifying $30 million in aid previously disbursed to deceased individuals. *(Sources: U.S. Department of Education press release, June 2025; FSA Partners electronic announcement, June 2025.)*"),

  H.h1("Contribution Summary"),
  H.pp("The three contribution areas verified by the development team are summarized below. Each is consistent with the Platform Team\u2019s charter of providing enabling process infrastructure to development work performed by others."),
  H.table([
    ["Contribution Area", "Description", "Impact"],
    ["Requirements Gathering",
     "Collected and documented customer requirements from institutional stakeholders (financial aid, admissions, registrar, IT) to define detection criteria and workflow needs.",
     "Ensured the tool addressed real operational pain points identified in the regional fraud cases above, rather than theoretical requirements."],
    ["Planning & Obstacle Resolution",
     "Assisted H. Seidi and M. Milstead with project planning, identified and helped resolve technical obstacles during the build cycle.",
     "Kept the project on track for a May 2026 ship date aligned with federal compliance timelines and ahead of Fall 2026 enrollment."],
    ["Scrum / GitHub Workflow Advocacy",
     "Advocated for and established Scrum methodology and GitHub-based version control, issue tracking, and PR workflows as non-optional project standards.",
     "Provided the process discipline necessary for a cross-functional tool with institutional compliance implications, consistent with AACRAO\u2019s recommendation that cross-functional teams with structured workflows lead fraud-prevention efforts."],
  ], [2500, 3500, 3360]),

  H.h1("Methodology Note \u2014 Curriculum and Practice"),
  H.pp("The Scrum / GitHub workflow advocated on this project is the same workflow the capstone curriculum teaches (see File 03, Objective 3 \u2014 the Sacred Workflow). This is not coincidence; it is the point. The methodology the program teaches its students is also the methodology its instructor advocates for institutional production work. The tool shipped using that methodology, executed by H. Seidi and M. Milstead, on a real institutional deliverable with measurable compliance implications."),
  H.pp("For purposes of this review, the relevant claim is narrower than \u201Cthe instructor built a tool.\u201D The relevant claim is that **the same workflow the curriculum trains students to perform is the workflow that delivered an internal compliance tool of institutional value**. That validation is what gives the curriculum its claim to industry alignment \u2014 not that students will encounter Scrum in their first job, but that the methodology has been used by their own department to ship software here."),

  H.h1("Alignment with Institutional Mission"),
  H.pp("The Ghost Student Discovery Tool directly protects the institution\u2019s ability to serve legitimate students by reducing enrollment fraud, safeguarding federal financial aid eligibility, and closing vulnerabilities that have already been exploited in documented, prosecuted cases targeting this institution. Deploying detection tooling places the institution ahead of the NC Community College System\u2019s current posture \u2014 which, based on the research summarized in Part B, has not yet adopted the AI-powered screening, identity verification, or system-wide fraud-prevention frameworks deployed by peer systems in Virginia, California, and Pennsylvania \u2014 and aligns with the U.S. Department of Education\u2019s escalating enforcement posture."),

  H.h1("Conclusion"),
  H.pp("**Minimum requirement:** Provide PM support; help shepherd the tool through development."),
  H.pp("**Actual delivery:**"),
  H.bullet("Stakeholder requirements documented from four institutional departments."),
  H.bullet("Project planning and obstacle resolution sustained across the build cycle."),
  H.bullet("Scrum / GitHub workflow established as a non-optional development standard, executed successfully by the development team."),
  H.bullet("Tool delivered on schedule (May 2026) into an institutional risk environment with active federal investigations in the region."),
  H.pp("Implementation credit, again, belongs to H. Seidi and M. Milstead. The PM contribution documented here was the supporting infrastructure that helped their work ship on a compliance-relevant schedule \u2014 and the workflow they used is the same workflow the program\u2019s curriculum teaches its students to perform."),
];

// -------------------- SUPPORTING RESEARCH --------------------
const research = [
  ...H.buildDivider({
    eyebrow: "PART B",
    title: "Supporting Research",
    subtitle: "Ghost-student fraud — the threat landscape and institutional response",
  }),

  H.h1("Supporting Research"),
  H.pp("This section establishes the threat landscape, peer-institution responses, and federal compliance context that justify the Ghost Student Discovery Tool as an institutional priority. The material is drawn from federal court records, DOJ press releases, DOE/OIG reports, investigative journalism (ABC News, ABC11, *Fortune*, WJLA), and higher-education industry sources (EDUCAUSE Review, AACRAO, IntelliBoard, EdSource)."),

  H.h2("Summary of Findings"),
  H.bullet("More than 200 active federal investigations into ghost-student schemes nationally; investigated fraud exceeds $350M over five years (DOE OIG)."),
  H.bullet("The largest prosecuted NC case named this institution as a victim; the perpetrator operated from the surrounding county."),
  H.bullet("Peer systems that deployed detection tooling have reduced fraud by more than 90%."),
  H.bullet("Federal compliance mandates effective Summer 2025 require identity verification for flagged FAFSA applicants at all Title IV institutions."),
  H.bullet("The NC Community College System has not yet adopted the AI-powered screening or identity-verification frameworks deployed by California, Virginia, and Pennsylvania peers."),

  H.h2("The Largest Prosecuted NC Case"),
  H.pp("The largest ghost-student prosecution in North Carolina history centers on Cynthia Denise Melvin, a 60-year-old resident of the local metropolitan area, who pleaded guilty on February 26, 2025, to conspiracy to commit wire fraud. Between 2016 and 2023, Melvin recruited approximately 80 straw students \u2014 real people whose personal information she collected \u2014 then impersonated them to submit admission applications and FAFSAs at multiple community colleges across the state\u2019s Middle and Eastern judicial districts. She completed coursework under their names, communicated with schools as if she were the students, and routed financial aid refunds through bank accounts she controlled."),
  H.pp("The targeted institutions included Wake Technical Community College (NC\u2019s largest), Cape Fear Community College, and the institution under review. The scheme generated more than $4.7 million in financial aid awards, of which over $3.5 million was actually disbursed. A federal search warrant at Melvin\u2019s home recovered troves of straw students\u2019 personal identifying information, FSA account credentials, and bank routing numbers. She was sentenced on June 24, 2025, to five years in federal prison and ordered to pay $3.64 million in restitution. Acting U.S. Attorney Daniel Bubar called it \u201Cone of the most significant federal student aid fraud schemes ever prosecuted in North Carolina.\u201D"),
  H.pp("Melvin\u2019s case is not isolated. Jerry Lynn Johnson Jr. of Clayton, NC, received 53 months in prison in January 2023 after admitting he used stolen identities to fraudulently enroll straw students at multiple colleges, stealing over $400,000 in federal aid. Brenda Joyce Hall of Cumberland County was charged with fabricating high-school transcripts through a sham home school called \u201CHalls of Knowledge\u201D to enroll unqualified individuals in Wake Tech\u2019s online programs, resulting in hundreds of thousands of dollars in fraudulent disbursements. U.S. Attorney Ellis Boyle confirmed in January 2026 that multiple additional investigations are actively underway in the Eastern District."),

  H.h2("The Mechanics of a Ghost-Student Scheme"),
  H.pp("The fraud follows a repeatable playbook that exploits structural features of community-college enrollment. Perpetrators first acquire personal data \u2014 Social Security numbers, dates of birth, names \u2014 from dark-web marketplaces, data breaches, phishing operations, or by recruiting willing participants for a cut of the proceeds. Some use identities of deceased individuals, prison inmates, nursing-home residents, or minors. Increasingly, fraudsters build synthetic identities that combine real and fabricated data, making detection harder."),
  H.pp("Armed with this information, they submit online applications to community colleges. Open-enrollment policies mean there are no GPAs, test scores, or competitive admissions requirements to clear. Many schools charge no application fee, making mass submissions cost-free. Automation has supercharged the process: at one institution, 50 fake applications arrived within two seconds. Scammers target asynchronous online courses where physical presence is never required."),
  H.pp("Once enrolled, the ghost student files a FAFSA reporting minimal income to maximize Pell Grant eligibility \u2014 currently up to roughly $7,400 per year, none of which must be repaid. Because community-college tuition is low (often $2,000\u2013$3,000 annually for a full course load), the majority of the Pell Grant is disbursed directly to the \u201Cstudent\u201D as a cash refund for books and living expenses. Fraudsters use AI to generate essays, discussion posts, and quiz responses \u2014 maintaining the illusion of attendance just past the census date when financial aid locks in. Some have deployed deepfake video to pass identity verification calls. After the disbursement hits a controlled bank account, the ghost vanishes. The cycle repeats at the next school."),

  H.h2("Across the Southeast, the Pattern Repeats"),
  H.pp("South Carolina\u2019s most prominent case differs from the typical external fraud ring but illustrates how ghost students can emerge from institutional misconduct. An investigation by the state\u2019s Office of Inspector General (December 2024) found that Northeastern Technical College had been auto-enrolling high-school dual-enrollment students in additional courses without their knowledge or consent through a \u201CFast Track\u201D program. The investigation uncovered $461,119 in improper spending and flagged the college\u2019s fraud risk level as \u201Cmoderate to moderately high.\u201D"),
  H.pp("Virginia offers the clearest southeastern success story. The Virginia Community College System \u2014 23 schools serving 230,000 students \u2014 saw fraudulent applications peak around 2018 at roughly 15% of all submissions (about 2,000 fake applications monthly). After implementing an identity-verification system in 2024 that requires applicants to submit front and back photos of a state-issued ID plus a live selfie, verified by an independent vendor, VCCS reduced fraud to less than 1% of applications by 2026."),
  H.pp("Other southeastern prosecutions include an Alabama case where defendants Byrom and Swint pleaded guilty to enrolling ineligible individuals using fabricated Tuskegee University transcripts in a scheme exceeding $250,000. Mississippi has been identified by both the DOE OIG and NASFAA as a state where fraud rings \u201Cfalsely enrolled hundreds of students in distance education programs.\u201D Nationally, major cases include a Maryland man who used 60 stolen identities to extract $6.7 million (sentenced to four years in 2023), an Arizona father-son team that stole $7 million before their arrests, and a Texas fraud ring pursuing $1.5 million using stolen identities."),

  H.h2("North Carolina\u2019s Response Lags Behind the Crisis"),
  H.pp("The North Carolina Community College System, the nation\u2019s third-largest with 58 institutions serving nearly 600,000 students, has taken some steps but lacks the aggressive posture adopted by peer systems. All 58 NCCCS colleges use the IntelliBoard analytics platform alongside the Moodle learning management system, which can track student engagement patterns, flag accounts with no substantive activity before census dates, and monitor IP addresses. IntelliBoard markets itself explicitly as a ghost-student detection tool and references its work with NCCCS."),
  H.pp("The system launched a Digital Credential Pilot Program in the 2024\u20132025 academic year, with Cape Fear Community College and Randolph Community College testing blockchain-based digital credential platforms (DigiCred and Certree, respectively). This initiative could eventually help verify student identities and academic histories more securely. Individual colleges have implemented their own safeguards: Durham Technical Community College requires official transcripts, mandatory advisor meetings (in-person or virtual), SSN duplication detection, and AI-powered systems to flag suspicious applications."),
  H.pp("However, research found no evidence that NCCCS or any individual NC community college has adopted ID.me, knowledge-based authentication, or biometric identity verification for enrollment \u2014 tools California has deployed systemwide since early 2024. The NCCCS website has no dedicated fraud-prevention page, and the system\u2019s compliance reviews focus primarily on Full-Time Equivalent enrollment accuracy rather than identity fraud. No North Carolina state legislation specifically targeting community-college enrollment fraud or mandating identity verification was identified \u2014 a notable gap compared to California, where lawmakers demanded a state audit and the Board of Governors voted to require ID verification for all applicants."),

  H.h2("Federal Mandates and Technology Are Reshaping the Defense"),
  H.pp("The federal response accelerated sharply in 2025. On June 6, the Department of Education announced \u201Csignificant actions to prevent fraud through identity verification,\u201D declaring that identity theft in student aid \u201Chas reached a level that imperils the federal student assistance programs.\u201D Key provisions now affecting every Title IV institution, including this one:"),
  H.bullet("**Summer 2025:** Roughly 125,000 first-time FAFSA applicants were required to verify identity using a valid, unexpired government-issued photo ID \u2014 presented in person, via live video call, or through NIST IAL-2 compliant remote-verification software. Schools must retain a copy of the ID."),
  H.bullet("**Fall 2025:** A permanent, centralized identity-screening process launched for all FAFSA applicants, with approximately 300,000 applications flagged for V4/V5 verification."),
  H.bullet("Statement of Educational Purpose eliminated as a standalone document; notarized statements alone no longer accepted."),
  H.bullet("DOE resumed cross-checking student aid records against the Social Security Death Index, immediately identifying $30 million in aid previously disbursed to deceased individuals."),
  H.pp("On the technology front, the most impactful innovation is LightLeap.AI, developed by N2N Services. Deployed at more than 80 of California\u2019s community colleges and expanding to Arizona, Michigan, and Minnesota, the platform uses device fingerprinting, IP tracking, time-zone analysis, cross-institutional data matching, and behavioral pattern recognition to flag suspicious applications in real time. In November 2025, N2N partnered with Ellucian to integrate the tool into Ellucian\u2019s admissions and financial aid platforms, which serve 2,800+ institutions globally."),
  H.pp("Other notable solutions include S.A.F.E. (Student Applicant Fraudulent Examination) from A.M. Simpkins & Associates, which helped Delaware County Community College in Pennsylvania go from 500+ ghost students in 2023 to just two in 2025. Identity-verification vendors including Nametag, Persona, Plaid, and Socure now market NIST IAL-2-compliant solutions to higher education. The AACRAO has published comprehensive guidance recommending cross-functional fraud-prevention teams, standardized red-flag checklists, and delayed financial aid disbursement tied to verified attendance."),

  H.h2("Best Practices the Institution Should Adopt"),
  H.pp("The evidence points to a layered defense strategy combining technology, process changes, and cross-institutional collaboration:"),
  H.bullet("**Identity verification at the front door.** Virginia\u2019s ID-plus-selfie system reduced fraud from 15% to under 1%."),
  H.bullet("**AI-powered application screening.** LightLeap.AI and S.A.F.E. detect patterns invisible to human reviewers \u2014 matching IP addresses, device fingerprints, email creation dates, and enrollment behaviors across institutions."),
  H.bullet("**Delayed and conditional disbursement.** Tying financial-aid releases to verified attendance past the census date, requiring mandatory advisor meetings, and enforcing the existing 30-day delay for first-time borrowers all narrow the window for cash-and-vanish schemes."),
  H.bullet("**Faculty engagement.** Requiring synchronous check-ins during the first week, early \u201Cproof of life\u201D assignments before census date, and systematic reporting of non-participating students catches ghosts that slip past automated systems."),
  H.bullet("**Cross-functional fraud teams.** AACRAO recommends standing committees with representatives from admissions, financial aid, the registrar, IT, and campus security meeting weekly during peak enrollment periods, with clear authority to place verification holds."),

  H.h2("Conclusion of the Research Brief"),
  H.pp("Ghost-student fraud represents a collision between community colleges\u2019 open-access mission and sophisticated criminal enterprises that exploit precisely those features designed to lower barriers for legitimate students. The southeastern United States is neither immune nor a secondary target \u2014 North Carolina alone has produced the state\u2019s largest-ever prosecution involving $4.7 million and 80 straw students, with multiple additional cases under active investigation. The most effective countermeasures combine identity verification at enrollment (proven to reduce fraud by over 90% in Virginia), AI-powered pattern detection (which catches twice as many fraudsters as human review), and process safeguards such as delayed disbursement and mandatory attendance verification."),
  H.pp("Federal mandates effective since mid-2025 now require photo-ID verification for flagged applicants at every Title IV institution, but the gap between compliance-minimum and best-practice-maximum remains wide. North Carolina and South Carolina community college systems would benefit significantly from adopting the technology solutions and systematic approaches that California and Virginia have already proven at scale, before the next wave of AI-powered fraud arrives. The Ghost Student Discovery Tool delivered by H. Seidi and M. Milstead under the project management arrangement described in Part A is a step in that direction \u2014 not a complete solution to a systemic problem, but a concrete institutional response to a documented, regionally prosecuted threat."),
];

// -------------------- ASSEMBLE --------------------
const doc = H.buildDoc({
  docTitle: "Objective 2 — Ghost Student Discovery Tool",
  instructorLabel: "[REDACTED]",
  sections: [
    { children: cover, noHeader: true, noFooter: true },
    { children: [...objectiveBody, ...research] },
  ],
});

H.Packer.toBuffer(doc).then(buf => {
  const outPath = '/home/claude/binder/02_Objective2_GhostTool.docx';
  fs.writeFileSync(outPath, buf);
  console.log(`Wrote ${outPath} (${buf.length} bytes)`);
});
