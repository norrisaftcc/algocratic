// build_00_front.js — Cover, Reading Guide, Executive Summary, Introduction
const fs = require('fs');
const H = require('./helpers');

// -------------------- COVER PAGE --------------------
const cover = H.buildCoverPage({
  eyebrow: "[REDACTED] TECHNICAL COMMUNITY COLLEGE",
  title: "Performance Review",
  subtitle: "Documentation Binder · 2025–2026",
  metadata: [
    { label: "Instructor", value: "[REDACTED]" },
    { label: "Department", value: "Computer Programming & Development" },
    { label: "Review Period", value: "July 1, 2025 – June 30, 2026" },
    { label: "Proposed Rating", value: "Exceeds Expectations" },
  ],
  dateLine: "Prepared June 2026 · For internal review",
});

// -------------------- READING GUIDE --------------------
const readingGuide = [
  ...H.buildDivider({
    eyebrow: "PART 1 · FRONT MATTER",
    title: "Reading Guide",
    subtitle: "How this binder is organized and how to navigate it",
    leadingBreak: false, // first section after cover; no preceding content
  }),

  H.h1("Reading Guide"),
  H.pp("This binder documents the achievement of three performance objectives during the 2025–2026 review period and the basis for the proposed \u201CExceeds Expectations\u201D rating. It is organized so that a reader pressed for time can read only the front matter and reach a defensible conclusion, while a reader doing a full review can move through the objective documents in any order."),

  H.h2("Recommended Reading Order"),
  H.numbered("**Executive Summary** (this binder, immediately following) \u2014 the rating argument in a single page."),
  H.numbered("**Introduction** (this binder, following the Executive Summary) \u2014 the pedagogical framework that underlies all three objectives."),
  H.numbered("**Objective Documents** \u2014 each is self-contained and may be read in any order:"),
  H.bullet("File 01 \u2014 Cross-Departmental Capstone Collaboration Framework", 1),
  H.bullet("File 02 \u2014 Ghost Student Discovery Tool", 1),
  H.bullet("File 03 \u2014 GitHub / Source Control Version Control (SCVC) Instructional Modules", 1),
  H.numbered("**Appendices** (File 04) \u2014 project documentation reference, lessons-learned summary, and a closing reflection."),

  H.h2("Quick Access by Purpose"),
  H.table([
    ["If you want\u2026", "Read\u2026"],
    ["The rating argument", "Executive Summary + the Objective 2 file"],
    ["The pedagogical framework", "Introduction + Appendix A"],
    ["Evidence for a specific objective", "The corresponding Objective file (01, 02, or 03)"],
    ["The complete picture", "All five files, in order"],
  ], [3120, 6240]),

  H.h2("What This Binder Documents"),
  H.pp("Each of the three performance objectives was achieved; that is the floor. The case for \u201CExceeds Expectations\u201D rests on what was delivered above that floor:"),
  H.bullet("**Infrastructure rather than single-use materials.** The frameworks built during this review period are documented for reuse across future terms, courses, and adjacent departmental collaborations. The marginal cost of running them again is now low."),
  H.bullet("**Methodology validated through real institutional delivery.** The Ghost Student Discovery Tool, developed by colleagues on the Platform Team, was delivered using the same Scrum/GitHub workflow that the capstone curriculum teaches. The instructor\u2019s contribution to that delivery (project management support, requirements documentation, workflow advocacy) used the same methodology students practice in CSC 289. The curriculum is therefore not a classroom abstraction; it has been used to ship software with institutional value."),
  H.bullet("**Outcomes measured against industry-aligned criteria.** Where the work touches employability (Objectives 1 and 3), the evidence base draws from current employer surveys and peer-reviewed CS-education research. Where the work touches institutional risk (Objective 2), the evidence base draws from federal prosecutions, U.S. Department of Education actions, and peer-institution outcomes."),

  H.h2("Document Structure (Per Objective)"),
  H.pp("Each objective file follows a consistent format:"),
  H.numbered("**Objective statement** \u2014 what the institution required."),
  H.numbered("**Why this work was the right call** \u2014 field-level evidence that established the approach as sound before the review period began."),
  H.numbered("**Implementation** \u2014 how the objective was achieved."),
  H.numbered("**Deliverables and outcomes** \u2014 what was produced and how it performed."),
  H.numbered("**Institutional value** \u2014 impact beyond the minimum required scope."),
  H.numbered("**Supporting evidence base** \u2014 citations and research grounding the approach."),

  H.h2("Evidence Standard"),
  H.pp("Every claim in this binder is grounded in either a concrete deliverable produced during the review period, a measurable outcome (student-success metrics, deployed projects, institutional impact), or published research and primary sources cited inline. Where research is referenced, the strongest available sources have been chosen \u2014 peer-reviewed where possible, primary-source where appropriate (federal court records, DOE actions, employer surveys)."),
  H.pp("Project repository files are referenced in Appendix A and are available for verification on request."),
];

// -------------------- EXECUTIVE SUMMARY --------------------
const execSummary = [
  ...H.buildDivider({
    eyebrow: "PART 1 · FRONT MATTER",
    title: "Executive Summary",
    subtitle: "The rating argument in a single page",
  }),

  H.h1("Executive Summary"),

  H.h2("Achievement Summary"),
  H.pp("All three performance objectives were achieved with measurable institutional impact."),

  H.h3("Objective 1 \u2014 Cross-Departmental Collaboration Framework"),
  H.pp("Formalized the Computer Science / Graphic Design capstone integration through a documented Creative Brief process, three structured milestones, and a multi-dimensional collaboration rubric. First full implementation in Spring 2026 produced five completed cross-disciplinary projects with 100% milestone completion and an average collaboration rubric score of 87/100. The framework is documented for reuse and is positioned for adoption by adjacent program pairings."),

  H.h3("Objective 2 \u2014 Ghost Student Discovery Tool"),
  H.pp("Provided project management support for the development and delivery of an internal fraud-detection utility addressing enrollment fraud and financial aid abuse. The tool was implemented by colleagues H. Seidi and M. Milstead and shipped in May 2026, aligned with federal compliance timelines and ahead of the Fall 2026 enrollment cycle. The instructor\u2019s contribution covered requirements gathering from institutional stakeholders, planning and obstacle resolution during the build cycle, and advocacy for Scrum/GitHub workflow as the mandatory development standard. The result is a working internal tool addressing a regional threat that has produced the largest prosecuted ghost-student fraud case in North Carolina history."),

  H.h3("Objective 3 \u2014 GitHub / SCVC Instructional Modules"),
  H.pp("Delivered four production-ready instructional modules (Issue Tracking, Branch & Merge, Pull Request Process, Self / Peer Code Review) implemented in CSC 289, with the foundational portions extended to CTS 285. The modules are organized under a coherent framework, the Sacred Workflow, grounded in signature-pedagogy theory (Shulman, 2005) and situated-learning research (Lave & Wenger, 1991), with student outcomes including 100% adoption of issue-first development, 0 instances of work lost to Git errors, and an average peer-review score of 85/100 across the cohort."),

  H.h2("Why the Proposed Rating is \u201CExceeds Expectations\u201D"),

  H.h3("1. Objective achievement plus methodology infrastructure"),
  H.pp("The standard expectation is to deliver three discrete objectives. What this review period delivered is three objectives **plus** a documented pedagogical framework with replication value across courses, terms, and departments. The marginal cost of running this work next year is materially lower than it would be without that infrastructure investment."),

  H.h3("2. Curriculum methodology validated through institutional delivery"),
  H.pp("The Ghost Student Discovery Tool was developed using the same Scrum/GitHub workflow students are taught in the capstone curriculum. The instructor was responsible for advocating and enforcing that workflow on the project, not for writing the implementation \u2014 H. Seidi and M. Milstead delivered the code. The relevant point for assessment is that the workflow taught in the classroom is the workflow that shipped an internal tool of institutional value. Curriculum-to-practice validation does not get more concrete than that."),

  H.h3("3. Scalable impact beyond original scope"),
  H.pp("The cross-departmental collaboration protocol is positioned for replication across adjacent program pairings. The SCVC modules are positioned for adoption in earlier courses, compressing later-course onboarding when students arrive already fluent in the workflow. The Ghost Tool, having shipped, continues to provide institutional value. None of these are one-and-done deliverables; each compounds."),

  H.h3("4. Industry alignment in the language employers use"),
  H.pp("Where the work touches employability, the language used in this binder is the language employers use in current hiring research \u2014 NACE Job Outlook 2025 / 2026, the World Economic Forum *Future of Jobs Report 2025*, the Stack Overflow Developer Survey 2024, GitHub\u2019s Octoverse 2025. This is deliberate. Community college graduates compete against four-year graduates in the regional labor market; the most defensible curriculum is one whose graduates can read employer job descriptions and recognize what is being asked of them."),

  H.h2("The Institutional Value Proposition"),
  H.pp("Traditional performance review measures objective completion. The argument in this binder is that the appropriate measure is **institutional return on the review period** \u2014 what continues to generate value after June 30, 2026, because of work done before it."),
  H.pp("By that measure, this review period produced: three objectives completed, one production tool shipped, one cross-departmental protocol established and ready for replication, four instructional modules ready for adoption by colleagues, and a documented pedagogical framework with adoption pathways into earlier courses in the program."),
  H.pp("The proposed rating reflects the difference between completing the assignments and building the infrastructure that makes the next set of assignments easier to complete well."),
];

// -------------------- INTRODUCTION --------------------
const introduction = [
  ...H.buildDivider({
    eyebrow: "PART 1 · FRONT MATTER",
    title: "Introduction",
    subtitle: "Pedagogical framework and methodology",
  }),

  H.h1("Introduction"),
  H.pp("This section establishes the pedagogical methodology underlying all three objectives and explains the framework references that appear throughout the binder. A reader who is interested only in objective outcomes may skip this section without losing the rating argument; readers interested in **how** the work was done will find the framework context here."),

  H.h2("The Underlying Challenge"),
  H.pp("Traditional computer science education faces a persistent and well-documented gap: students learn technical skills in isolation but struggle when those skills must integrate with team dynamics, ambiguous requirements, deadline pressure, and iterative feedback cycles. The real challenge is not writing code. It is writing code inside the messy human systems where software actually gets built."),
  H.pp("Industry reality, summarized from current research:"),
  H.bullet("Developers work in teams using Git and GitHub workflows; 93% of professional developers use Git (Stack Overflow Developer Survey 2024, n = 65,437)."),
  H.bullet("Requirements change mid-sprint; agile methodologies are now the dominant development practice across the industries computing students enter."),
  H.bullet("AI tools are standard rather than transgressive; current employer expectations assume junior developers use them productively."),
  H.bullet("Communication discipline matters as much as code quality; nearly 80% of employers screen for teamwork on new-graduate resumes (NACE Job Outlook 2025)."),
  H.bullet("Iteration is normal, not exceptional; production software ships in small increments through code review."),

  H.pp("The educational question is therefore not **whether** to teach these realities, but **how** to teach them in a way that produces durable behavioral formation rather than memorized procedure. That is the question the framework described below was built to answer."),

  H.h2("The AlgoCratic Futures Framework"),

  H.h3("What it is"),
  H.pp("An immersive instructional simulation that delivers technical curriculum through a thematically consistent narrative scaffold. Students progress through clearance levels (INFRARED \u2192 RED \u2192 ORANGE \u2192 YELLOW \u2192 GREEN) that correspond to skill development, while navigating in-class scenarios that exaggerate, in legible satirical form, the workplace dynamics they will actually encounter."),
  H.pp("The simulation is delivery wrapper, not content. The technical curriculum underneath is conventional, rigorous, and assessable. The satirical framing is, by design, approximately 5% of the instructional load \u2014 enough to make the framework memorable and to lower the affective cost of failure, but never so much that it competes with the technical content."),

  H.h3("Why it works"),
  H.pp("The framework rests on four established mechanisms drawn from learning research:"),
  H.pp("**1. Psychological safety through thematic distancing.** When an in-class scenario assigns an absurd deadline, students recognize the absurdity while practicing real deadline-negotiation behavior. Failure becomes \u201Calgorithmic miscalibration\u201D rather than personal inadequacy. The technical content underneath is still graded, but the social cost of an early attempt going badly is reduced \u2014 which makes iteration psychologically affordable. This mechanism is consistent with the literature on growth-mindset interventions in technical education."),
  H.pp("**2. Growth velocity over absolute skill.** Clearance progression measures learning rate, not current position. A student who improves from weak to mediocre \u201Coutranks\u201D a student who stays consistently good. This is a deliberate choice that rewards effort and iteration \u2014 the dispositions software development actually requires. It also reduces the structural disadvantage borne by students with weaker prior preparation, which is consequential in a community college context."),
  H.pp("**3. Normalized AI tool usage with comprehension requirements.** Students are explicitly taught to use Claude and similar tools, but must iterate on outputs and demonstrate comprehension during assessment. This matches industry practice while interrupting the failure mode where AI output is submitted without understanding. AI tools are introduced after fundamentals are established (at ORANGE clearance, not earlier), so students have the foundation to evaluate suggestions rather than accept them uncritically."),
  H.pp("**4. Real workflows with memorable framing.** Students learn genuine Scrum methodology, Git workflows, and code review practice. The satirical framing makes the learning more memorable, not different. The \u201CSacred Workflow\u201D taught in the capstone is real branch / pull request / review / merge discipline \u2014 students remember it in part because of the ceremonial framing, but the framing is in service of the actual professional behavior."),

  H.h2("Connection to the Performance Objectives"),

  H.h3("Objective 1 \u2014 Cross-Departmental Collaboration"),
  H.pp("The clearance system provided structural scaffolding for integrating Graphic Design students (designated GREY clearance) into Computer Science capstone teams. The framework supplied role clarity, milestone synchronization, and ceremony participation \u2014 the elements informal cross-departmental coordination typically lacks."),

  H.h3("Objective 2 \u2014 Ghost Tool Development"),
  H.pp("The same Scrum / GitHub workflow that the curriculum teaches was the project standard for the Ghost Tool implementation, with the instructor responsible for advocating and enforcing that workflow as project manager. The fact that the tool shipped through that workflow is independent evidence that the workflow scales beyond the classroom \u2014 not because the instructor wrote the code, but because the team that did, on a real institutional deliverable, succeeded using the methodology students practice in CSC 289."),

  H.h3("Objective 3 \u2014 GitHub / SCVC Modules"),
  H.pp("The four Sacred Workflow modules (Issue Tracking, Branch & Merge, Pull Request, Code Review) are the core technical content of the framework, delivered through the immersive scaffolding. Students learn real Git discipline in memorable ceremonial form, and the discipline transfers \u2014 measurably so, as the outcome data in File 03 shows."),

  H.h2("On Naming Conventions and Tone"),
  H.pp("Reviewers may encounter terms in the supporting materials that are specific to the AlgoCratic Futures framework \u2014 clearance levels, the Sacred Workflow, the Algorithm \u2014 alongside conventional academic and professional language. A few notes on how these are used:"),
  H.bullet("**The technical material is conventional.** Every framework term has a one-line industry translation in the relevant module. \u201CSacred Workflow\u201D = standard branch / PR / review / merge discipline."),
  H.bullet("**The framing is light at capstone level.** The simulation is denser in introductory courses (RED / ORANGE) and lighter at the capstone (YELLOW), where students need direct technical instruction more than narrative scaffolding."),
  H.bullet("**Where in-voice flourishes appear in supplemental materials**, they are marked as such. The body of this binder is written in conventional professional register."),

  H.h2("On the Evidence Standard"),
  H.pp("This binder is built on the premise that pedagogical decisions should be defensible against published research and industry data rather than against the instructor\u2019s preferences alone. The evidence appendix within each objective file is therefore not decoration; it is the basis on which the framework was built. The research had established that this kind of work is correct before the review period began. What this review period demonstrates is that the work was done."),
];

// -------------------- ASSEMBLE DOCUMENT --------------------
const doc = H.buildDoc({
  docTitle: "Front Matter",
  instructorLabel: "[REDACTED]",
  sections: [
    // Cover page: own docx-section, no header/footer
    { children: cover, noHeader: true, noFooter: true },
    // Body: one docx-section containing the three parts with internal dividers
    { children: [...readingGuide, ...execSummary, ...introduction] },
  ],
});

H.Packer.toBuffer(doc).then(buf => {
  const outPath = '/home/claude/binder/00_FrontMatter.docx';
  fs.writeFileSync(outPath, buf);
  console.log(`Wrote ${outPath} (${buf.length} bytes)`);
});
